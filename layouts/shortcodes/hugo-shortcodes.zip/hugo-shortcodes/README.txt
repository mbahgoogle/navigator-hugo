DATE: 2016-12-30
VERSION: 1.1
SHORTCODES: Twitch, JSFiddle, Pastebin, Box, Google Maps

README:
This archive contains a set of shortcodes that can be used with Hugo's
static site generator to easily embed external content into posts and
pages.

You can use these shortcodes on any type of site including commercial
sites.

If you like these shortcodes and find them useful, please link to my
blog at http://geekthis.net.

CHANGELOG:
Version 1.1 (2016-12-30)
	- Created shortcodes for Box and Google Maps.
	- Updated some documentation inside the sample post file.
Version 1.0 (2016-12-29)
	- Created initial shortcodes for Twitch, JSFiddle, and Pastebin.
	- Created sample post that demonstrates each shortcode.
